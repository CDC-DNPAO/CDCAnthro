# https://kbroman.org/pkg_primer/pages/github.html

# install_github("wrengels/HWxtest", subdir="pkg")
library(devtools)
install_github("CDC-DNPAO/CDCAnthro")

# To put your package on GitHub, you’ll need to get a GitHub account. Then follow the instructions in my git/github guide on creating a new git repository. In brief:
#
#    Change to the package directory
# Initialize the repository with git init
# Add and commit everything with git add . and git commit
# Create a new repository on GitHub
# Connect your local repository to the GitHub one
#
# git remote add origin https://github.com/username/reponame
# Push everything to github
#
# git push -u origin master

# open terminal (under tools) - should already be in the correct directory
git remote add origin https://github.com/CDC-DNPAO/CDCAnthro
git push -u origin master

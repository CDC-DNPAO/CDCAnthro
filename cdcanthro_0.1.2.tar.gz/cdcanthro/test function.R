
d <- eg(sex=1:2,Age=100,wt=seq(20,50,10),ht=1); d$bmi <- d$wt
d <- cdcanthro(d,Age,wt,ht,bmi)
d

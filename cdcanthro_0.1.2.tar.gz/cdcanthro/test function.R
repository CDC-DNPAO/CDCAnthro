
d <- eg(SEXC=1:2, Age=100,wt=seq(20,50,10),ht=1); d$bmi <- d$wt; d

nms <- names(d)
if (length(grep('^sex$|^Sex$|^SEX$', nms)) != 1) {
        stop ("A child's sex can named 'sex', 'SEX', or 'Sex'. Further, there can be only
              one of these 3 variables in your data")
}
if (is.na(match('sex', names(d))) & 'SEX' %in% nms) {setnames(d,'SEX','sex')}
if (is.na(match('sex', names(d))) & 'Sex' %in% nms) {setnames(d,'Sex','sex')}

d <- cdcanthro(d,Age,wt,ht,bmi)
d

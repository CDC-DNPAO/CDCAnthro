x <- fread('~/Sync/R/Anal/Growth_Charts/Data/CDCref_d.csv'); some(x); tabyl(x$`_AGEMOS1`)[1:10,]

# library(cdcanthro)
d <- expand.grid(sex=c('g','b'), age=sample(24.25:240.25,3),wt=20,ht=1); d
d$bmi <- d$wt
# names(d)[names(d)=='bmxwt'] <- 'wt'; d
setDT(d)
data <- copy(d)
# data[,let(age=age-0.25)]
out <- cdcanthro(data,age,wt,ht, all=FALSE);
out

d <- fread('~/Sync/R/Packages/test_data/nhanes.csv')
# d <- d[!is.na(bmi)]; nrow(d); qsu(d)
out <- cdcanthro(d,agemos,wt,ht,bmi, all=TRUE); out
qsu(out)


data <- expand.grid(sex=1:2,age=c(125,180,200),wt=seq(20,60,20),ht=1);
data$bmi <- data$wt; data
# summary(data)
d <- cdcanthro(data,age,wt,ht,bmi)
d




nms <- grep('^sex$',names(d),ignore.case = TRUE, value = TRUE); nms
if (nms!='sex') {names(d)[which(names(d)==nms)] <- 'sex'}
d

if (length(grep('^sex$|^Sex$|^SEX$', nms)) != 1) {
   stop ("A child's sex can named 'sex', 'SEX', or 'Sex'. Further, there can be only
              one of these 3 variables in your data")
}
# if (nms !='sex') {
# if (is.na(match('sex', names(d))) & 'SEX' %in% nms) {setnames(d,'SEX','sex')}
# if (is.na(match('sex', names(d))) & 'Sex' %in% nms) {setnames(d,'Sex','sex')}
# }


usethis::use_git
Error in libgit2::git_signature_default :
   config value 'user.name' was not found

library(remotes)
# remotes::install_github("beansrowning/CDCAntro")
# remotes::install_github("CDC-DNPAO/CDCAnthro", force=TRUE)

install.packages( 'https://raw.github.com/CDC-DNPAO/CDCAnthro/master/cdcanthro_0.1.2.tar.gz', type='source', repos=NULL )
library(cdcanthro)
?cdcanthro
d <- expand.grid(SEX=1:2,Age=100,wt=seq(20,60,20),ht=1); d$bmi <- d$wt; d
d <- cdcanthro(d,Age,wt,ht,bmi)
round(d,2)


library(devtools)
install_github("CDC-DNPAO/CDCAnthro")
library(cdcanthro)

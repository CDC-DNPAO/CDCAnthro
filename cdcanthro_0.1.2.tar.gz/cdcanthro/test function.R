
d <- eg(Sex=1:2,Age=100,wt=seq(20,50,10),ht=1); d$bmi <- d$wt; d
d <- cdcanthro(d,Age,wt,ht,bmi)
d




nms <- grep('^sex$',names(d),ignore.case = TRUE, value = TRUE); nms
if (nms!='sex') {names(d)[which(names(d)==nms)] <- 'sex'}
d

if (length(grep('^sex$|^Sex$|^SEX$', nms)) != 1) {
   stop ("A child's sex can named 'sex', 'SEX', or 'Sex'. Further, there can be only
              one of these 3 variables in your data")
}
if (nms !='sex') {
if (is.na(match('sex', names(d))) & 'SEX' %in% nms) {setnames(d,'SEX','sex')}
if (is.na(match('sex', names(d))) & 'Sex' %in% nms) {setnames(d,'Sex','sex')}
}
